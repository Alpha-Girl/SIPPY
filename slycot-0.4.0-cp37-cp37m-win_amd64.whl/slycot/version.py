
# THIS FILE IS GENERATED FROM SLYCOT SETUP.PY
short_version = '0.4.0'
version = '0.4.0'
full_version = '0.4.0'
git_revision = 'Unknown'
release = True

if not release:
    version = full_version
